//
//  Readme.md
//  CarTrivia!
//
//  Created by Devansh Malik on 5/20/22.
//

# CarTrivia!
#### Video Demo: https://youtu.be/Hrjfye67zvI
#### Description: The app i created is called CarTrivia! the reason i created this trivia is due to my long loving interest in different models, brands, and so much more about cars. When I was first deciding on what to create for my final project, i was not really sure. but then, i was watching a tiktok video talking about guessing a car logo, and then i thought, wow, i should make a car model guessing trivia! and ultimately, that is what I created.                                      In my app, there are around 4 files used. in contentview file, it is used as the cover page. in contentview, i created the coverpage, including the transiton of the coverpage leading into the other pages, and also the font, backgorund image uploaded through assets, and also font size, background placement, and adding in a button.                 In page 2, 3, and 4, I added questions about different models of cars. In each page they would redirect to the next after the answer is selected correctly, and if not, it would be redirected back to the same page to answer the question till it was correct. In each page, I added a different background image uploaded through the assets, and then i created buttons, a navigation bar title, to ask the question, and the buttons so the user can answer the question.


import Foundation


